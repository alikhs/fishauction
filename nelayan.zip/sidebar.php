<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">    
                  <a href="../home.php"><p class="centered"><img src="../../atribut/img/logo.png" class="img-circle" width="200"></p></a>
                  <li class="mt">
                      <a href="../../level/admin/mahasiswa/data-mahasiswa.php">
                          <i class="fa fa-users"></i>
                          <span>Kotak Masuk</span>
                      </a>
            <a href="../../level/admin/dosen/data-dosen.php">
                          <i class="fa fa-user"></i>
                          <span>Profile</span>
                      </a>
            </a>
            <a href="../../level/admin/permasalahan/data-permasalahan.php">
                          <i class="fa fa-windows"></i>
                          <span>Kelola Data Nelayan</span>
                      </a>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>