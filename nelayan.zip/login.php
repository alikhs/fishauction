<!DOCTYPE HTML>
<html>
	<head>
		<title>Aplikasi Penjualan Hasil Tangkapan Nelayan</title>
		<link rel="shortcut icon" href="atribut/img/policon.png">
		<link rel="stylesheet" href="atribut/css/login.css" />
		
		<link rel="stylesheet" href="atribut/font-awesome/css/font-awesome.css" />
		
	</head>
	<body>
		<center><img src="atribut/img/nelayan icon.png" width="200px" style="padding-top: 80px" /> </center>
		<form method="post" action="proses_login.php" class="login">
    <p>
      <label for="login"><i class="fa fa-fw fa-user fa-2x" style="color: #0d7796;"></i></label>
      <input type="text" name="username" placeholder="username" autofocus required="" title="Username harus diisi">
    </p>

    <p>
      <label for="password"><i class="fa fa-fw fa-lock fa-2x" style="color: #0d7796;"></i></label>
      <input type="password" name="password" placeholder="password" required="" title="Password harus diisi">      
    </p>

    <p class="login-submit">
      <button type="submit" class="login-button" name="login">Login</button>
    </p>
    </form>
	
   <!-- <center style="padding-top: 80px;"><b>Website Visualisasi</b></center> -->
    
	</body>
</html>