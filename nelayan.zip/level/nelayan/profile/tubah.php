<?php
error_reporting(0);
session_start();
if ($_SESSION['level']=='nelayan') {
include('../../../koneksi.php');
$username = $_SESSION['username'];
$nama = $_POST['nama'];
$nohp = $_POST['nohp'];
	//$nohp = ubahnohp($a);
	$nohp = str_replace(" ","",$nohp);
     // kadang ada penulisan no hp (0274) 778787
     $nohp = str_replace("(","",$nohp);
     // kadang ada penulisan no hp (0274) 778787
     $nohp = str_replace(")","",$nohp);
     // kadang ada penulisan no hp 0811.239.345
     $nohp = str_replace(".","",$nohp);
 
     // cek apakah no hp mengandung karakter + dan 0-9
     if(!preg_match('/[^+0-9]/',trim($nohp))){
         // cek apakah no hp karakter 1-3 adalah +62
         if(substr(trim($nohp), 0, 3)=='+62'){
             $hp = trim($nohp);
         }
         // cek apakah no hp karakter 1 adalah 0
         elseif(substr(trim($nohp), 0, 1)=='0'){
             $hp = '+62'.substr(trim($nohp), 1);
         }
     }
	 

$fileName = $_FILES['picture']['name']; //get the file name
$fileSize = $_FILES['picture']['size']; //get the size
$fileError = $_FILES['picture']['error']; //get the error when upload

$ubah = mysql_query("UPDATE user SET nama='$nama', nohp='$hp' WHERE username='$username'");

if ($ubah) {
	echo "<script>alert('Data berhasil disimpan'); window.location = 'profile.php'</script>";
}
else {
	echo "<script>alert('Data gagal disimpan'); window.location = 'profile.php'</script>";
}

}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../login.php'</script>";
}

if($fileSize > 0 ){
$move = move_uploaded_file($_FILES['picture']['tmp_name'], 'attribut/img/'.$fileName); //save image to the folder
$masuk = mysql_query("UPDATE user SET foto='$fileName', folder='atribut/img/$fileName' WHERE username='$username'");
}
?>