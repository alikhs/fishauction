<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">    
                  <a href="../profile/profile.php"><p class="centered"><?php echo'<img src="../../../atribut/img/'.$_SESSION['foto'].'" class="img-circle" width="200">'; ?></p></a>
                  <li class="mt">
                      <a href="../../nelayan/tangkapan/tangkapan.php">
                          <i class="fa fa-users"></i>
                          <span>Hasil Tangkapan Nelayan</span>
                      </a>
            <a href="../../nelayan/profile/profile.php">
                          <i class="fa fa-user"></i>
                          <span>Profile</span>
                      </a>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>