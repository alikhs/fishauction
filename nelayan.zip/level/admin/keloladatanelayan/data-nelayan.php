<?php
error_reporting(0);
session_start();
if ($_SESSION['level']=='admin') {
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Aplikasi Penjualan Hasil Tangkapan Nelayan</title>
    <link rel="shortcut icon" href="../../../atribut/img/policon.png">
    <link href="../../../atribut/css/bootstrap.css" rel="stylesheet" />
    <link href="../../../atribut/css/style.css" rel="stylesheet" />
    <link href="../../../atribut/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <script src="../../../atribut/js/jquery.js"></script> 
    <link href="../../../atribut/datatables/jquery.dataTables.css" rel="stylesheet" /> 
	<script src="../../../atribut/datatables/jquery.dataTables.js"></script>
	<script src="../../../atribut/popup/jquery.confirm.js"></script>
	<script>
	$(document).ready( function() {
		 $('#datatables').dataTable( {
		 "iDisplayLength": 10,
		  "aLengthMenu": [[10 , 30, 50, 100, -1], [10, 30, 50, 100, "All"]]
		  } );
		 } );
	</script>
    
  </head>
  <body>
  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
      	<!--logo start-->
        <a class="logo"><b>Aplikasi Penjualan Hasil Tangkapan Nelayan</b></a>
        <!--logo end-->              
        <div class="top-menu">
        	<ul class="nav pull-right top-menu">
        		<div style="color: #FFFFFF; padding: 18px 0px 5px 0px; float:left; font-size: 18px; font-family: sans-serif; "><?php echo $_SESSION['nama'];?></div>
                    <li><a id="simpleConfirm" href="../../../logout.php" class="logout"><i class="fa fa-sign-out"></i></a></li>
                    <script>
           			 $("#simpleConfirm").confirm();
    				</script>
    				<script src="../../../atribut/popup/bootstrap.min.js"></script>
					<script src="../../../atribut/popup/run_prettify.js"></script>
            </ul>
        </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <?php
            include("sidebar.php");
       ?>
<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
          	<div class="row mt">
          		<div class="col-lg-12">
          			
          			<h4 class="mb"><i class="fa fa-angle-right"></i> Data Nelayan</h4>
          			<div class="form-panel">
          			<div class="panel panel-default">
          				<div class="panel-body">
          				<table class="table table-striped table-bordered" id="datatables">	
      	 					<thead>
         					<tr>
              
							<td align="center"><b>Nama</b></td>
							<td align="center"><b>Username</b></td>
							<td align="center"><b>No HP</b></td>
							<td align="center"><b>Foto</b></td>
							<td align="center"><b>Aksi</b></td>
                			</tr>
         					</thead>
         				<tbody>
         				<?php
						include("../../../koneksi.php");
						$sql=mysql_query("SELECT * FROM user where level='nelayan'");
						
						while ($data=mysql_fetch_array ($sql)) {
							echo "<tr>
							<td align='center'>$data[nama]</td>
							<td align='center'>$data[username]</td>
							<td align='center'>$data[nohp]</td>
							<td align='center'><img width='100px' src=../../../$data[folder]></td>
													
							<td align='center'><a title='hapus' href='hapus-nelayan.php?kode=$data[nohp]' class='simpleConfirm'><button type='button' class='btn btn-danger'><i class='fa fa-trash-o'> Hapus </i></button></a></td></tr>";
						echo"<script>
           			 	$('.simpleConfirm').confirm();
    					</script>
    					<script src='../../atribut/popup/bootstrap.min.js'></script>
						<script src='../../atribut/popup/run_prettify.js'></script>";
						} 
						?> 
         				</tbody>
         				</table>
           				</div>
          			</div>
          			</div>
          		</div>
          	</div>
		</section><!--/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
          	Copyright &copy; 2017 <b>Muhammad Arafat Zaipon Saputra
              <a href="data-nelayan.php" class="go-top">
                  <i class="fa fa-angle-double-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  	</section>    
  </body>
</html>
<script src="../../../atribut/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../../../atribut/js/common-scripts.js"></script>
<?php
}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../../login.php'</script>";
}
?>