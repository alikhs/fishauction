<?php
error_reporting(0);
session_start();
if ($_SESSION['level']=='admin') {
?>
<html>
 <head>
  <script type="text/javascript">
   function ajaxrunning()
   {
    if (window.XMLHttpRequest)
    {
     xmlhttp=new XMLHttpRequest();
    }
    else
    {
     xmlhttp =new ActiveXObject("Microsoft.XMLHTTP");
    }
 
    xmlhttp.onreadystatechange=function()
    {
     if (xmlhttp.readyState==4 && xmlhttp.status==200)
     {
      document.getElementById("inbox").innerHTML = xmlhttp.responseText;
     }
    }
 
    xmlhttp.open("GET","auto.php");
    xmlhttp.send();
    setTimeout("ajaxrunning()", 5000);
   }
  </script>
    <title>Aplikasi Penjualan Hasil Tangkapan Nelayan</title>
    <link rel="shortcut icon" href="../../../atribut/img/policon.png">
    <link href="../../../atribut/css/bootstrap.css" rel="stylesheet" />
    <link href="../../../atribut/css/style.css" rel="stylesheet" />
    <link href="../../../atribut/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <script src="../../../atribut/js/jquery.js"></script> 
    <link href="../../../atribut/datatables/jquery.dataTables.css" rel="stylesheet" /> 
	<script src="../../../atribut/datatables/jquery.dataTables.js"></script>
	<script src="../../../atribut/popup/jquery.confirm.js"></script>
	<script>
	$(document).ready( function() {
		 $('#datatables').dataTable( {
		 "iDisplayLength": 10,
		  "aLengthMenu": [[10 , 30, 50, 100, -1], [10, 30, 50, 100, "All"]]
		  } );
		 } );
	</script>
    
  </head>
  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
      	<!--logo start-->
        <a class="logo"><b>Aplikasi Penjualan Hasil Tangkapan Nelayan</b></a>
        <!--logo end-->              
        <div class="top-menu">
        	<ul class="nav pull-right top-menu">
        		<div style="color: #FFFFFF; padding: 18px 0px 5px 0px; float:left; font-size: 18px; font-family: sans-serif; "><?php echo $_SESSION['nama'];?></div>
                    <li><a id="simpleConfirm" href="../../../logout.php" class="logout"><i class="fa fa-sign-out"></i></a></li>
                    <script>
           			 $("#simpleConfirm").confirm();
    				</script>
    				<script src="../../../atribut/popup/bootstrap.min.js"></script>
					<script src="../../../atribut/popup/run_prettify.js"></script>
            </ul>
        </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <?php
            include("sidebar.php");
       ?>
 <body onload="ajaxrunning()">
 
  <div id="inbox"></div>
  

<!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
          	Copyright &copy; 2017 <b>Muhammad Arafat Zaipon Saputra
              <a href="index.php" class="go-top">
                  <i class="fa fa-angle-double-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  	</section>    
  </body>
</html>
<script src="../../../atribut/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../../../atribut/js/common-scripts.js"></script>
<?php
}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../../login.php'</script>";
}
?>
