<?php

// proses pembacaan sms di inbox setelah dibaca, sms akan disimpan di tabel sms_inbox

function ngecekinbox()
{
 // mencari pesan SMS yang masih false (blm diproses)
 $query = "SELECT * FROM inbox WHERE processed = 'false'";
 $hasil = mysql_query($query);

 while ($data = mysql_fetch_array($hasil))
 {
  $sum = 0;
  $noTelp = $data['SenderNumber'];
  $idmodem = $data['RecipientID'];
  
  // jika UDH nya ada (mrpkan part long SMS)
  if ($data['UDH'] != '')
  {
   // baca prefix UDH 
   $chop = substr($data['UDH'], 0, 8);
   // baca bagian UDH untuk mendapatkan total part
   $n = (int) substr($data['UDH'], 8, 2);
   $text = "";
   
   // mencari semua part SMS berdasarkan struktur UDH dan nomor pengirimnya 
   for ($i=1; $i<=$n; $i++)
   {
    // mengkonstruksi UDH untuk setiap part
    $udh = $chop.sprintf("%02s", $n).sprintf("%02s", $i);
    $query3 = "SELECT * FROM inbox WHERE udh = '$udh' AND SenderNumber = '$noTelp' AND processed = 'false'";
    $hasil3 = mysql_query($query3);
    if (mysql_num_rows($hasil3) > 0) $sum++;
   }
   
   // jika semua part sudah ada (lengkap), lakukan penggabungan pesan 
   if ($sum == $n)
   {
    for ($i=1; $i<=$n; $i++)
    {
     // mengkonstruksi UDH untuk setiap part
     $udh = $chop.sprintf("%02s", $n).sprintf("%02s", $i);
     // membaca pesan dari setiap part berdasarkan UDH dan nomor pengirimnya
     $query3 = "SELECT * FROM inbox WHERE udh = '$udh' AND SenderNumber = '$noTelp' AND processed = 'false'";
     $hasil3 = mysql_query($query3);
     $data3 = mysql_fetch_array($hasil3);
     // proses penggabungan pesan
     $text .= $data3['TextDecoded'];
     $id = $data3['ID'];
     // menghapus pesan yang sudah diproses
     $query3 = "DELETE FROM inbox WHERE ID = '$id'";
     mysql_query($query3);
    }
  
    // memasukkan pesan utuh hasil penggabungan ke tabel SMS_INBOX
    $notelp = $data['SenderNumber'];
	
    $time = $data['ReceivingDateTime'];
    $text = str_replace("'", "\'", $text); 

    $query2 = "INSERT INTO sms_inbox(pesan, nohp, waktu, modem) VALUES ('$text', '$notelp', '$time')";
    mysql_query($query2); 

	$query1 = "SELECT * FROM user WHERE nohp = '$notelp'";
	$hasil1 = mysql_query($query1);
	while ($data1 = mysql_fetch_array($hasil1)) {
	$nama = $data1['nama'];
	}
						
	$tangkapan = explode('#',$text);
	
	$kode = $tangkapan[0];	
	$namaikan = $tangkapan[1];
	$berat = $tangkapan[2];
	$harga = $tangkapan[3];
	$totalharga = $berat * $harga;
	if($kode = 'Ubah')
	{
		$query4 = "UPDATE tangkapan SET berat='$berat', harga='$harga', totalharga='$totalharga' WHERE namaikan='$namaikan' AND nohp='$notelp'";
		$verifikasi4 = mysql_query($query4);	
	}
		
	
   }   
  }
  else 
  {
   // jika UDH nya tidak ada (short SMS)
   $id = $data['ID'];
   $notelp = $data['SenderNumber'];
   
   $time = $data['ReceivingDateTime'];   
   $text = str_replace("'", "\'", $data['TextDecoded']);
   
   // menghapus pesan yang sudah diproses
   $query2 = "DELETE FROM inbox WHERE ID = '$id'";
   mysql_query($query2);
   
   // memasukkan pesan ke SMS_INBOX
   $query2 = "INSERT INTO sms_inbox(pesan, nohp, waktu) VALUES ('$text', '$notelp', '$time')";
   mysql_query($query2);
   
    $query1 = "SELECT * FROM user WHERE nohp = '$notelp'";
	$hasil1 = mysql_query($query1);
	while ($data1 = mysql_fetch_array($hasil1)) {
	$nama = $data1['nama'];
	}
	
	$tangkapan = explode('#',$text);
	
	$kode = $tangkapan[0];	
	$namaikan = $tangkapan[1];
	$berat = $tangkapan[2];
	$harga = $tangkapan[3];
	$totalharga = $berat * $harga;
	$message = "Data Berhasil ditambah";
	$message1 = "Data Berhasil diubah";
	$message2 = "Data Berhasil dihapus";
	$tanggal = date("Y-m-d");
	
	if($kode == 'Tambah')
	{
		$querytambah = "INSERT INTO tangkapan(id, nohp, namaikan, berat, harga, totalharga, tanggal) VALUES (NULL, '$notelp', '$namaikan', '$berat', '$harga', '$totalharga', '$tanggal')";
		$b = mysql_query($querytambah);
		//exec('c:\gammu\bin\gammu-smsd-inject.exe -c c:\gammu\bin\smsdrc EMS '.$notelp.' -text "'.$message.'"');
	}	
		if($b){
		exec('c:\gammu\bin\gammu-smsd-inject.exe -c c:\gammu\bin\smsdrc EMS '.$notelp.' -text "'.$message.'"');
		}

	if($kode == 'Ubah')
	{
		$queryubah = "UPDATE tangkapan SET berat='$berat', harga='$harga', totalharga='$totalharga' WHERE namaikan='$namaikan' AND nohp='$notelp'";
		$a = mysql_query($queryubah);	
		//exec('c:\gammu\bin\gammu-smsd-inject.exe -c c:\gammu\bin\smsdrc EMS '.$notelp.' -text "'.$message.'"');
	}	
		if($a){
		exec('c:\gammu\bin\gammu-smsd-inject.exe -c c:\gammu\bin\smsdrc EMS '.$notelp.' -text "'.$message1.'"');
		}
		
	if($kode == 'Hapus')
	{
		$queryhapus = "DELETE FROM tangkapan WHERE nohp='$notelp' AND namaikan ='$namaikan'";
		$c = mysql_query($queryhapus);
		//exec('c:\gammu\bin\gammu-smsd-inject.exe -c c:\gammu\bin\smsdrc EMS '.$notelp.' -text "'.$message.'"');
	}
		if($c){
		exec('c:\gammu\bin\gammu-smsd-inject.exe -c c:\gammu\bin\smsdrc EMS '.$notelp.' -text "'.$message2.'"');
		}

  }
  }
}

?>