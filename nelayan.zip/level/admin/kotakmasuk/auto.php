<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
          	<div class="row mt">
          		<div class="col-lg-12">
          			
          			<h4 class="mb"><i class="fa fa-angle-right"></i> Kotak Masuk</h4>
          			<div class="form-panel">
          			<div class="panel panel-default">
          				<div class="panel-body">
						
          				<table class="table table-striped table-bordered" id="datatables">	
      	 					<thead>
         					<tr>
							<td align="center"><b>Id</b></td>
							<td align="center"><b>Pengirim</b></td>
							<td align="center"><b>Waktu </b></td>
							<td align="center"><b>Pesan SMS</b></td>
							<td align="center"><b>Aksi</b></td>
							</tr>
         					</thead>
         				<tbody>
						
         				<?php
						include 'config.php';
						include 'function.php';

						// proses membaca inbox dan menyimpan ke tabel sms_inbox
						ngecekinbox();

						// tampilkan data inbox sesuai urutan waktu
						$query = "SELECT * FROM sms_inbox ORDER BY waktu DESC";
						$hasil = mysql_query($query);
						

					
						while ($data = mysql_fetch_array($hasil)) {
							$id = $data['id'];
							 $nohp = $data['nohp']; 
							$time = $data['waktu'];
							$text = $data['pesan'];
						
							echo "<tr>
							<td align='center'>".$id."</td>
							<td align='center'>".$nohp."</td>
							<td align='center'>".$time."</td>
							<td align='center'>".$text."</td>
							<td align='center'><a title='hapus' href='hapus.php?kode=".$id."' class='simpleConfirm'><button type='button' class='btn btn-danger'><i class='fa fa-trash-o'> Hapus </i></button></a></td></tr>";
						echo"<script>
           			 	$('.simpleConfirm').confirm();
    					</script>
    					<script src='../../atribut/popup/bootstrap.min.js'></script>
						<script src='../../atribut/popup/run_prettify.js'></script>";
						} 
						
						?> 
						
         				</tbody>
         				</table>
           				</div>
          			</div>
          			</div>
          		</div>
          	</div>
		</section><!--/wrapper -->
      </section><!-- /MAIN CONTENT -->
						