<?php

// koneksi ke database

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nelayan';

mysql_connect($dbhost, $dbuser, $dbpass);
mysql_select_db($dbname);