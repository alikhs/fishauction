<?php
error_reporting(0);
session_start();
if ($_SESSION['level']=='admin') {
include('../../../koneksi.php');
$id = $_GET[kode];
$hapus = mysql_query("Delete from tangkapan where id='$id'");
echo "<script>";
echo "$('#simpleConfirm').confirm();";
echo "</script>";  				
echo "<script src='../../../atribut/popup/bootstrap.min.js'>";
echo "</script>";
echo "<script src='../../../atribut/popup/run_prettify.js'>";
echo "</script>";
				
if($hapus){
	echo "<script>alert('Data berhasil dihapus'); window.location = 'tangkapan.php'</script>";
}else{
	echo "<script>alert('Data gagal dihapus'); window.location = 'tangkapan.php'</script>";
}
}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../../login.php'</script>";
}
?>