<?php
error_reporting(0);
session_start();
if ($_SESSION['level']=='admin') {
?>
<!DOCTYPE html>
<html>
  <head>
    <title>APLIKASI PENJUALAN HASIL TANGKAPAN NELAYAN</title>
    <link rel="shortcut icon" href="../../../atribut/img/policon.png">
    <link href="../../../atribut/css/bootstrap.css" rel="stylesheet" />
    <link href="../../../atribut/css/style.css" rel="stylesheet" />
    <link href="../../../atribut/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <script src="../../../atribut/js/jquery.js"></script> 
    <link href="../../../atribut/datatables/jquery.dataTables.css" rel="stylesheet" /> 
	<script src="../../../atribut/datatables/jquery.dataTables.js"></script>
	<script src="../../../atribut/popup/jquery.confirm.js"></script>
	<script>
	$(document).ready( function() {
		 $('#datatables').dataTable( {
		 "iDisplayLength": 10,
		  "aLengthMenu": [[10 , 30, 50, 100, -1], [10, 30, 50, 100, "All"]]
		  } );
		 } );
	</script>
    
  </head>
  <body>
  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
      	<!--logo start-->
        <a class="logo"><b>APLIKASI PENJUALAN HASIL TANGKAPAN NELAYAN</b></a>
        <!--logo end-->              
        <div class="top-menu">
        	<ul class="nav pull-right top-menu">
        		<div style="color: #FFFFFF; padding: 18px 0px 5px 0px; float:left; font-size: 18px; font-family: sans-serif; "><?php
				include ('../../../koneksi.php');
				$nohp = $_SESSION['nohp'];
				$data = mysql_fetch_array(mysql_query("SELECT nama FROM user WHERE nohp='$nohp'"));
				echo $data['nama'];
				?></div>
                    <li><a id="simpleConfirm" href="../../../logout.php" class="logout"><i class="fa fa-sign-out"></i></a></li>
                    <script>
           			 $("#simpleConfirm").confirm();
    				</script>
    				<script src="../../../atribut/popup/bootstrap.min.js"></script>
					<script src="../../../atribut/popup/run_prettify.js"></script>
            </ul>
        </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <!--sidebar start-->
		<?php
            include("sidebar.php");
       ?>
<!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
						<?php
						include("../../../koneksi.php");
						$nohp = $_SESSION['nohp'];
						$sql=mysql_query("SELECT * FROM user where nohp=$nohp ");
						$data=mysql_fetch_array ($sql);
						?>
          	<div class="row mt">
          		<div class="col-lg-12">
          			
          			<h4 class="mb"><i class="fa fa-angle-right"></i> Ubah Profil</h4>
          			<div class="form-panel">
          			<div class="panel panel-default">
          				<div class="panel-heading">
          					<div class="panel-body">    
          					<form  method="post" action="tubah.php" onsubmit="return confirm('Apakah Ingin Mengubah Profil?');">      					
          					<div class="col-md-10">
          					<label class="col-sm-2 control-label"><b>Nama<label style="color: red;">&nbsp&nbsp *</label></b></label>
          					<div class="col-sm-5"><input class="form-control" type="text" name="nama" placeholder="Nama" autofocus 
          						 title="Nama harus diisi" value="<?php echo $data[nama] ?>"/></div>
          					</div>
          					
          					<div class="col-md-10">
          					<label class="col-sm-2 control-label"><b>No Hp<label style="color: red;">&nbsp&nbsp *</label></b></label>
          					<div class="col-sm-5"><input class="form-control" type="text" name="nohp" placeholder="No Hp" 
          						 title="No Hp  harus diisi" value="<?php echo $data[nohp] ?>" /></div>
          					</div>
							
							<div class="col-md-10">
          					<label class="col-sm-2 control-label"><b>Foto<label style="color: red;">&nbsp&nbsp *</label></b></label>
          					<div class="col-sm-5"><input type="file" name="picture" placeholder="Foto" 
          						 title="Foto  harus diisi"/></div>
          					</div>
							
          					
          					<div class="col-md-10">
          					<label class="col-sm-2 control-label"></label>
          					<div class="col-sm-5"><input class="btn btn-primary" type="submit" value="Simpan"/><a href="data-dosen.php">&nbsp; &nbsp; &nbsp; Batal</a></div>
          					</div>
          					</div>
          					</form>
          			</div>
          			</div>
          			</div>
					<h4 class="mb"><i class="fa fa-angle-right"></i> Ubah Password</h4>
					<div class="form-panel">
          			<div class="panel panel-default">
          				<div class="panel-heading">
          					<div class="panel-body">    
          					<form  method="post" action="tubahpassword.php" >      					
          					
          					<div class="col-md-10">
          					<label class="col-sm-2 control-label"><b>Password Baru<label style="color: red;">&nbsp&nbsp *</label></b></label>
          					<div class="col-sm-5"><input class="form-control" type="password" name="pass_baru" placeholder="Password Baru" 
          						required="" /></div>
          					</div>
							
							<div class="col-md-10">
          					<label class="col-sm-2 control-label"><b>Konfirmasi Password Baru<label style="color: red;">&nbsp&nbsp *</label></b></label>
          					<div class="col-sm-5"><input class="form-control" type="password" name="pass_ulangi" placeholder="Konfirmasi Password Baru" 
          						required="" /></div>
          					</div>
											
          					
          					<div class="col-md-10">
          					<label class="col-sm-2 control-label"></label>
          					<div class="col-sm-5"><input class="btn btn-primary" type="submit" value="Simpan"/><a href="data-dosen.php">&nbsp; &nbsp; &nbsp; Batal</a></div>
          					</div>
          					</div>
          					</form>
          			</div>
          			</div>
          			</div>
          
          		</div>
			</div>
		</section><!--/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
          	Copyright &copy; 2017 <b>Muhammad Arafat Zaipon Saputra
              <a href="data-dosen.php" class="go-top">
                  <i class="fa fa-angle-double-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  	</section>    
  </body>
</html>
<script src="../../../atribut/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../../../atribut/js/common-scripts.js"></script>
<?php
}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../../login.php'</script>";
}
?>