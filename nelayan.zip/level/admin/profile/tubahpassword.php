<?php
error_reporting(0);
session_start();
$username = $_SESSION['username'];
if ($_SESSION['level']=='admin') {
include('../../../koneksi.php');
//$r=mysql_fetch_array(mysql_query("SELECT * FROM user WHERE username=$username"));


//$pass_lama=MD5($_POST[pass_lama]);
$pass_baru=MD5($_POST[pass_baru]);

if (empty($pass_baru) or empty($_POST[pass_ulangi])){
  echo "<p align=center>Anda harus mengisikan semua data pada form Ganti Password.<br />"; 
  echo "<a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a></p>";
}
else{ 
// Apabila password lama cocok dengan password admin di database
  if ($pass_baru==md5($_POST[pass_ulangi])){
    mysql_query("UPDATE user SET password = '$pass_baru' where username= '$username'");
    header('location:profile.php');
  }
  else{
    echo "<p align=center>Password baru yang Anda masukkan sebanyak dua kali belum cocok.<br />"; 
    echo "<a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a></p>";  
  }

}
}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../../login.php'</script>";
}
?>