<?php
error_reporting(0);
session_start();
if ($_SESSION['level']=='admin') {
	
include('../../../koneksi.php');
$username = $_SESSION['username'];
$nama = $_POST['nama'];
$nohp = $_POST['nohp'];

$fileName = $_FILES['picture']['name']; //get the file name
$fileSize = $_FILES['picture']['size']; //get the size
$fileError = $_FILES['picture']['error']; //get the error when upload

$ubah = mysql_query("UPDATE user SET nama='$nama', nohp='$nohp' WHERE username='$username'");

if ($ubah) {
	echo "<script>alert('Data berhasil disimpan'); window.location = 'profile.php'</script>";
}
else {
	echo "<script>alert('Data gagal disimpan'); window.location = 'profile.php'</script>";
}
if($fileSize > 0 ){
$move = move_uploaded_file($_FILES['picture']['tmp_name'], 'foto/'.$fileName); //save image to the folder
$masuk = mysql_query("UPDATE user SET foto='$fileName', folder='foto/$fileName' WHERE id='$id'");
}
}else{
	echo "<script>alert('Anda tidak memiliki hak akses!!'); window.location='../../../login.php'</script>";
}
?>