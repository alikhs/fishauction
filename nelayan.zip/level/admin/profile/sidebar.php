<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">    
              	  <a href="../kotakmasuk/index.php"><p class="centered"><img src="../../../atribut/img/admin.gif" class="img-circle" width="200"></p></a></p></a>
                  <li class="mt">
                       <a href="../kotakmasuk/index.php">
                          <i class="fa fa-users"></i>
                          <span>Kotak Masuk</span>
                      </a>
				<a href="../../admin/profile/profile.php">
                          <i class="fa fa-user"></i>
                          <span>Profile</span>
                      </a>
					  </a>
				<a href="../tangkapan/tangkapan.php">
                          <i class="fa fa-user"></i>
                          <span>Tangkapan</span>
                      </a>
           
				<a href="../../admin/keloladatanelayan/data-nelayan.php">
                          <i class="fa fa-windows"></i>
                          <span>Kelola Data Nelayan</span>
                      </a>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>