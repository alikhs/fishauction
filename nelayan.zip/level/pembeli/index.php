<!DOCTYPE HTML>
<html>
	<head>
		<title>Aplikasi Penjualan Hasil Tangkapan Nelayan</title>
		<link href="css/style.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		<!----webfonts---->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
		<!----//webfonts---->
		<!----start-alert-scroller---->
		<script src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/jquery.easy-ticker.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$('#demo').hide();
			$('.vticker').easyTicker();
		});
		</script>
		<!----start-alert-scroller---->
		<!-- start menu -->
		<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
		<script type="text/javascript" src="js/megamenu.js"></script>
		<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
		<script src="js/menu_jquery.js"></script>
		<!-- //End menu -->
		<!---slider---->
		<link rel="stylesheet" href="css/slippry.css">
		<script src="js/jquery-ui.js" type="text/javascript"></script>
		<script src="js/scripts-f0e4e0c2.js" type="text/javascript"></script>
		<script>
			  jQuery('#jquery-demo').slippry({
			  // general elements & wrapper
			  slippryWrapper: '<div class="sy-box jquery-demo" />', // wrapper to wrap everything, including pager
			  // options
			  adaptiveHeight: false, // height of the sliders adapts to current slide
			  useCSS: false, // true, false -> fallback to js if no browser support
			  autoHover: false,
			  transition: 'fade'
			});
		</script>
		<!----start-pricerage-seletion---->
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
		<script type='text/javascript'>//<![CDATA[ 
			$(window).load(function(){
			 $( "#slider-range" ).slider({
			            range: true,
			            min: 0,
			            max: 500,
			            values: [ 100, 400 ],
			            slide: function( event, ui ) {  $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
			            }
			 });
			$( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) + " - $" + $( "#slider-range" ).slider( "values", 1 ) );
			
			});//]]>  
		</script>
		<!----//End-pricerage-seletion---->
		<!---move-top-top---->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
		<!---//move-top-top---->
	</head>
	<body>
		<!---start-wrap---->
			<!---start-header---->
			<div class="header">
				<div class="top-header">
					<div class="wrap">
						<div class="top-header-left">
							<ul>
								<!---cart-tonggle-script---->
								<script type="text/javascript">
									$(function(){
									    var $cart = $('#cart');
									        $('#clickme').click(function(e) {
									         e.stopPropagation();
									       if ($cart.is(":hidden")) {
									           $cart.slideDown("slow");
									       } else {
									           $cart.slideUp("slow");
									       }
									    });
									    $(document.body).click(function () {
									       if ($cart.not(":hidden")) {
									           $cart.slideUp("slow");
									       } 
									    });
									    });
								</script>
								<!---//cart-tonggle-script---->
								
							</ul>
						</div>
						
						<div class="top-header-right">
							<ul>
								<li><a href="../../login.php">Login</a><span> </span></li>
								<li><a href="../../daftar-nelayan.php">Daftar Nelayan</a></li>
							</ul>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
				<!----start-mid-head---->
				<div class="mid-header">
					<div class="wrap">
						<div class="mid-grid-right">
							<a href="index.php"><span> </span></a>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
				<!----//End-mid-head---->
				<!----start-bottom-header---->
				<div class="header-bottom">
					<div class="wrap">
					<!-- start header menu -->

					</div>
				</div>
				</div>
				<!----//End-bottom-header---->
			<!---//End-header---->
		<!----start-image-slider---->
		<div class="img-slider">
			<div class="wrap">
			<ul id="jquery-demo">
			  <li>
			    <a href="#slide1">
			      <img src="images/nelayan-5.jpg" alt="" />
			    </a>
			    <div class="slider-detils">
			    	<h3>Nelayan.com</h3>
			    	<span></span>
			    </div>
			  </li>
			  <li>
			    <a href="#slide2">
			      <img src="images/nelayan-2.jpg"  alt="" />
			    </a>
			     <div class="slider-detils">
			    	<h3>Nelayan.com</h3>
			    	<span></span>
			    	
			    </div>
			  </li>
			  <li>
			    <a href="#slide3">
			      <img src="images/nelayan-7.jpg" alt="" />
			    </a>
			     <div class="slider-detils">
			    	<h3>Nelayan.com</label></h3>
			    	<span></span>
			    	
			    </div>
			  </li>
			</ul>
			</div>
		</div>
		<div class="clear"> </div>
		<!----//End-image-slider---->
		<!----start-price-rage--->
		</br>
		
		<div class="content" align="justify" style="font-size:25px;color:black;">
		<div class="wrap">
		<p>nelayan.com merupakan aplikasi penjualan ikan, update menggunakan <i>sms gateway</i> langsung dari hasil tangkapan nelayan. pembelian dapat dilakukan dengan memilih ikan sesuai dengan update terkini. untuk melakukan pembelian  dapat menghubungi nelayan untuk melakukan transaksi pembelian.</p>
		</div>
		</div>
		
		
		<!----//End-price-rage--->
		<!--- start-content---->
		<div class="content">
			<div class="wrap">
					
						<?php
						include("koneksi.php");
						$sql=mysql_query("SELECT a.*, b.* FROM tangkapan a, user b WHERE a.nohp = b.nohp group by namaikan order by id desc");
						while ($data=mysql_fetch_array ($sql)) {
						?>

						
												
						<div class="product-grid last-grid" style="border-color:green">
							<div>
								<center><img style="width:200px" src="images/ikon ikan.png" title="<?php echo"$data[namaikan]"; ?>" /></a>
								
								<p style="font-size:30px;color:green;"><?php echo"$data[namaikan]"; ?></p>
								</center>
							</div>
							
							<div style="background-color:#008B8B">
								<div style = "color:white">
								Nama Nelayan : <?php echo "$data[nama]"; ?><br>
								No Hp : <?php echo"$data[nohp]"; ?><br>
								Berat :  <?php echo"$data[berat]"; ?> kg<br>
								Harga per KG : Rp. <?php echo"$data[harga]"; ?><br>
								Tanggal :  <?php echo"$data[tanggal]"; ?><br>
								</div>
							</div>
							
						</div>
						
												
						<?php
						}
						?>
						
						
				
				<div class="clear"> </div>
			</div>
		</div>
		<!---- start-bottom-grids---->
		<div class="bottom-grids">
			<div class="bottom-top-grids">
				<div class="wrap">
					<div class="bottom-top-grid">
						<h4></h4>
						<ul>
							
						</ul>
					</div>
					<div class="bottom-top-grid">
						<h4></h4>
						<ul>
							
						</ul>
					</div>
					<div class="bottom-top-grid last-bottom-top-grid">
						<h4>Nelayan.com - Ikan Segar Dengan Harga Terjangkau </h4>
						<p style="font-size:15px">Nelayan.com merupakan pasar ikan online yang dikelola langsung oleh nelayan. Hasil Tangkapan ikan...</p>
						<a class="learn-more" href="#">baca selanjutnya</a>
					</div>
					<div class="clear"> </div>
				</div>
			</div>
			<div class="bottom-bottom-grids">
				<div class="wrap">
					<div class="bottom-bottom-grid">
						<h6></h6>
					</div>
					<div class="bottom-bottom-grid">
						<h6></h6>
					</div>
					<div class="bottom-bottom-grid last-bottom-bottom-grid">
						<h6>SOSMED</h6>
						
		    				<img src="icon/facebook.png" width="32" alt="Facebook">
		    				<img src="icon/twitter.png" width="32" alt="Twitter">
		    				<img src="icon/linkedin.png" width="32" alt="LinkedIn">
							<img src="icon/rss.png" width="32" alt="RSS Feed">
					</div>
					<div class="clear"> </div>
				</div>
			</div>
		</div>
		<!---- //End-bottom-grids---->
		<!--- //End-content---->
		<!---start-footer---->
		<div class="footer">
			<div class="wrap">
				<div class="footer-left">
					<ul>
						<li><a href="#">Copyright &copy; 2017 <b>Muhammad Arafat Zaipon Saputra<b></a></li>
						
						<div class="clear"> </div>
					</ul>
				</div>
				
				<div class="clear"> </div>
			</div>
		</div>
		<!---//End-footer---->
		<!---//End-wrap---->
	</body>
</html>

