<?php
header('location:level/pembeli/index.php'); 
?>